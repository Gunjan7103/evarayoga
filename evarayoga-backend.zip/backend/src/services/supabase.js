import {createClient} from '@supabase/supabase-js';
import {env} from '../config/env.js';
export const supabaseAdmin=createClient(env.supabaseUrl,env.supabaseServiceRoleKey,{auth:{autoRefreshToken:false,persistSession:false}});
export const supabasePublic=createClient(env.supabaseUrl,env.supabaseAnonKey);
